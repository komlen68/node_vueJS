from django.contrib import admin
from .models import Proizvodjac, Roba
admin.site.register(Proizvodjac)
admin.site.register(Roba)

